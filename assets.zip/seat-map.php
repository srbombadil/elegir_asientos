
<?php
// Load the seat map data from the database
global $wpdb;
$seats = $wpdb->get_results("SELECT * FROM seat_map WHERE product_id = 12");

// Generate the seat map HTML
$seat_map_html = '<table class="seat-map">';
for ($row = 1; $row <= 24; $row++) {
  $seat_map_html .= '<tr>';
  for ($seat = 1; $seat <= 12; $seat++) {
    $seat_map_html .= '<td class="seat';
    foreach ($seats as $seat_data) {
      if ($seat_data->row_number == $row && $seat_data->seat_number == $seat) {
        $seat_map_html .= ' ' . $seat_data->status;
      }
    }
    $seat_map_html .= '">' . $seat . '</td>';
  }
  $seat_map_html .= '</tr>';
}
$seat_map_html .= '</table>';
?>

<!-- Display the seat map on the page -->
<div class="seat-map-container">
  <?php echo $seat_map_html; ?>
</div>

<!-- Add the JavaScript for seat selection and payment -->
<script>
  var selectedSeats = [];
  var seatPrice = {
    "1-6": 10,
    "7-12": 8,
    "13-24": 5
  };
  var totalPrice = 0;

  // Add click event listener to each seat
  var seats = document.querySelectorAll('.seat');
  seats.forEach(function(seat) {
    seat.addEventListener('click', function() {
      // Check if the seat is available
      if (!this.classList.contains('occupied')) {
        // Toggle the seat selection
        this.classList.toggle('selected');
        var seatNumber = this.textContent;
        var seatRow = this.parentNode.rowIndex + 1;
        var seatId = seatRow + '-' + seatNumber;
        // Add or remove the selected seat from the list
        if (selectedSeats.includes(seatId)) {
          selectedSeats.splice(selectedSeats.indexOf(seatId), 1);
          totalPrice -= seatPrice[getSeatRange(seatRow)];
        } else {
          selectedSeats.push(seatId);
          totalPrice += seatPrice[getSeatRange(seatRow)];
        }
        // Update the total price
        document.getElementById('total-price').textContent = '$' + totalPrice;
        // Update the hidden input field with the selected seats
        document.getElementById('selected-seats').value = selectedSeats.join(',');
      }
    });
  });

  // Get the seat range based on the row number
  function getSeatRange(rowNumber) {
    if (rowNumber >= 1 && rowNumber <= 6) {
      return "1-6";
    } else if (rowNumber >= 7 && rowNumber <= 12) {
      return "7-12";
    } else if (rowNumber >= 13 && rowNumber <= 24) {
      return "13-24";
    }
  }
</script>

<!-- Add the payment form -->
<form id="payment-form" method="POST" action="">
  <input type="hidden" name="selected_seats" id="selected-seats" value="">
  <input type="hidden" name="total_price" id="total-price-input" value="">
  <button type="submit" class="checkout-button button alt wc-forward">Pagar</button>
</form>
