  // Insert a new order in the orders table
  $order_id = $wpdb->insert(
    'orders',
    array(
      'product_id' => 12,
      'customer_name' => $_POST['customer_name'],
      'customer_email' => $_POST['customer_email'],
      'selected_seats' => implode(',', $selected_seats),
      'total_price' => $total_price,
      'order_date' => current_time('mysql')
    ),
    array('%d', '%s', '%s', '%s', '%d', '%s')
  );
  // Redirect to the thank you page if the order was successfully processed
  if ($order_id !== false) {
    $thankyou_url = site_url('/thank-you');
    wp_redirect($thankyou_url);
    exit;
  } else {
    echo '<p>There was an error processing your order. Please try again later.</p>';
  }
}
?>
<h2>Checkout</h2>
<p>Please enter your name and email address to complete your order.</p>
<form method="POST">
  <table>
    <tr>
      <td>Name:</td>
      <td><input type="text" name="customer_name" required></td>
    </tr>
    <tr>
      <td>Email:</td>
      <td><input type="email" name="customer_email" required></td>
    </tr>
    <tr>
      <td>Total price:</td>
      <td><span id="total-price">$0</span></td>
    </tr>
  </table>
  <input type="hidden" name="selected_seats" id="selected-seats" value="">
  <input type="hidden" name="total_price" id="total-price-input" value="">
  <input type="submit" value="Complete Order">
</form>
<script src="<?php echo plugin_dir_url(__FILE__) . 'seat-map.js'; ?>"></script>
