var selectedSeats = [];
var seatPrice = {
  "1-6": 10,
  "7-12": 8,
  "13-24": 5
};
var totalPrice = 0;

// Add click event listener to each seat
var seats = document.querySelectorAll('.seat');
seats.forEach(function(seat) {
  seat.addEventListener('click', function() {
    // Check if the seat is available
    if (!this.classList.contains('occupied')) {
      // Toggle the seat selection
      this.classList.toggle('selected');
      var seatNumber = this.textContent;
      var seatRow = this.parentNode.rowIndex + 1;
      var seatId = seatRow + '-' + seatNumber;
      // Add or remove the selected seat from the list
      if (selectedSeats.includes(seatId)) {
        selectedSeats.splice(selectedSeats.indexOf(seatId), 1);
        totalPrice -= seatPrice[getSeatRange(seatRow)];
      } else {
        selectedSeats.push(seatId);
        totalPrice += seatPrice[getSeatRange(seatRow)];
      }
      // Update the total price
      document.getElementById('total-price').textContent = '$' + totalPrice;
      // Update the hidden input field with the selected seats
      document.getElementById('selected-seats').value = selectedSeats.join(',');
    }
  });
});

// Get the seat range based on the row number
function getSeatRange(rowNumber) {
  if (rowNumber >= 1 && rowNumber <= 6) {
    return "1-6";
  } else if (rowNumber >= 7 && rowNumber <= 12) {
    return "7-12";
  } else if (rowNumber >= 13 && rowNumber <= 24) {
    return "13-24";
  }
}
